Sidr
============

This is the Bower package for the Sidr jQuery Plugin. For a further description, documentation and others visit: [http://www.berriart.com/sidr](http://www.berriart.com/sidr)
